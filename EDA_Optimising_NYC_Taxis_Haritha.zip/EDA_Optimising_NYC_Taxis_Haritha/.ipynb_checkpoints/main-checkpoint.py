def main():
    print("Hello from exploratory-data-analysis!")


if __name__ == "__main__":
    main()
